Oracle PL/SQL Trigger Programs
Name: Ausura Keshar
Enrollment No.: 92500527109

This folder contains five separate SQL programs:
01_restrict_weekends.sql
02_restrict_salary_above_50000.sql
03_copy_inserted_emp_to_newemp.sql
04_copy_old_emp_to_newemp_on_update.sql
05_copy_old_emp_to_newemp_on_delete.sql

Run the scripts in Oracle SQL Developer using Run Script (F5), or in SQL*Plus using @filename.sql.
Programs 3, 4, and 5 share the NEWEMP table. Run Program 3 first to create NEWEMP, then run Programs 4 and 5.
The examples assume the classic Oracle EMP columns: EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, DEPTNO.
Test using a practice database. The example test statements insert, update, or delete records.
