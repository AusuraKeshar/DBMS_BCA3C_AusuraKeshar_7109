PL/SQL Procedures and Functions - Assignment
Name: Ausura Keshar
Enrollment No.: 92500527109

Files:
01-10 contain the ten solved programs. Each SQL file includes the program name and student details as comments.

How to run:
1. Open Oracle SQL*Plus or SQL Developer.
2. Connect to your Oracle schema.
3. Enable output with SET SERVEROUTPUT ON (included in the scripts).
4. Run a script using SQL*Plus: @01_message_procedure.sql
   In SQL Developer, open the file and use Run Script (F5).
5. Programs 2, 3, 6, 7, and 8 use the standard Oracle EMP table and assume it has EMPNO, ENAME, DEPTNO, and SAL columns. If your EMP table uses different column names, adjust them.
6. Programs 5 and 10 use the ACCOUNT table. Program 5 creates the table and inserts sample records. If you run it more than once, remove the existing ACCOUNT table first or skip the CREATE TABLE and sample INSERT statements.
7. Programs 2, 6, and 7 modify salaries. Use a practice database and review data before running. COMMIT is included in the calling blocks.
8. Program 6 increases every employee's salary by 5% as an example because no exact update values were specified.
